import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userheader',
  templateUrl: './userheader.component.html',
  //styleUrls: ['./userheader.component.css']
})
export class UserheaderComponent implements OnInit {

  constructor(public auth:AuthenticationService,public router:Router) { }

  ngOnInit() {
  }

}
